本品使用Qt进行开发，并且使用了opencv、tesseract、FFmpeg。
其中opencv、tesseract及其依赖库使用vcpkg进行下载。
FFmpeg使用官方推荐的编译版本（https://github.com/BtbN/FFmpeg-Builds/releases）